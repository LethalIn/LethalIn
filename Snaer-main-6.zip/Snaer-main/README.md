# Snaer
### Russian
Привет, этот репозиторий - пока что доступен только для немногих людей. Если вы знаете об этом моде вы везунчик!(или контрибутор) Этот мод пока что завязан только на небольшом количестве предметов. 

Основу сделал: Lehanchic25

Создатель мода: Lethal Employee

### English
Hi, this repository is only available to a few people so far. If you know about this mode, you are lucky!(or a contributor) This mod is currently tied only to a small number of items. 

The basis was made by: Lehanchic25

Mod Creator: Lethal Employee

[![Stars](https://img.shields.io/github/stars/Lehanchic25/Snaer?color=7289da&label=⭐️%20Please%20Star%20Snaer%21)](https://github.com/Lehanchic25/Snaer)
[![Download](https://img.shields.io/github/v/release/Lehanchic25/Snaer?color=6aa84f&include_prereleases&label=Latest%20version&logo=github&logoColor=white&)](https://github.com/Lehanchic25/Snaer/releases)[![Total Downloads](https://img.shields.io/github/downloads/Lehanchic25/Snaer/total?color=7289da&label&logo=docusign&logoColor=white)](https://github.com/Lehanchic25/Snaer/releases)
[![Discord](https://img.shields.io/discord/1278276676811358238?style=for-the-badge&color=ff9199&logo=discord&label=Snaer%20Server)](https://discord.gg/Y7UhsehPrT)
